Freeze Da City: Da Outlets Saga — GBA Engine Stub
=================================================
This is a non-compiled starter for devkitARM + TONC (or Butano). It includes:
- src/main.c : game loop, input, basic fighter struct
- gfx/: placeholders for character sheets (PNG) and stages (PNG)
- Makefile : template (requires devkitARM in PATH)
- data/: JSON for roster, stage names, controls mapping

Build (desktop required):
1) Install devkitPro + devkitARM (https://devkitpro.org/wiki/Getting_Started)
2) Install grit for image conversion, or use Butano tools
3) In this folder: `make` → produces `fdc_saga.gba`
4) Load the resulting .gba into Delta

Mapping (Delta/GBA):
- A = Light    B = Heavy   L = EX   R = Super   START = Pause

NOTE: PNGs are provided; you'll need to convert to 4bpp/8bpp tile data or Butano assets.
