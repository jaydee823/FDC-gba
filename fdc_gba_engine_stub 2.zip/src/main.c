#include <gba.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    int x, y;
    int vx, vy;
    int hp;
    int facing; // 1 right, -1 left
} Fighter;

Fighter p1, p2;
int timer = 99;
int roundNum = 1;
int p1Wins = 0, p2Wins = 0;
int ko = 0;

void reset_round() {
    timer = 99; ko = 0;
    p1.hp = 1000; p2.hp = 1000;
    p1.x = 40; p1.y = 120;
    p2.x = 120; p2.y = 120;
}

void damage(int who, int amount){
    if (who==2){ p2.hp -= amount; if (p2.hp<0) p2.hp=0; if(p2.hp==0) ko=1; }
    else { p1.hp -= amount; if (p1.hp<0) p1.hp=0; if(p1.hp==0) ko=1; }
}

int main(void) {
    irqInit();
    irqEnable(IRQ_VBLANK);

    // Mode 0, BG2 as bitmap-ish placeholder via OBJ later (simplified)
    REG_DISPCNT = MODE_0 | BG0_ON | OBJ_ON | OBJ_1D_MAP;

    reset_round();

    while (1) {
        VBlankIntrWait();
        scanKeys();
        u16 keys = keysHeld();

        // simple move
        p1.vx = 0; p1.vy = 0;
        if (keys & KEY_LEFT) p1.vx = -1;
        if (keys & KEY_RIGHT) p1.vx = 1;
        if (keys & KEY_UP) p1.vy = -1;
        if (keys & KEY_DOWN) p1.vy = 1;

        p1.x += p1.vx; p1.y += p1.vy;
        if (p1.x<0) p1.x=0; if (p1.x>160-16) p1.x=160-16;
        if (p1.y<0) p1.y=0; if (p1.y>240-32) p1.y=240-32;

        // dummy AI
        if (p2.x > p1.x) p2.x--;
        else p2.x++;

        // attacks
        if (keysDown() & KEY_A) {
            int dist = p1.x - p2.x; if (dist<0) dist = -dist;
            if (dist < 24) damage(2, 50);
        }
        if (keysDown() & KEY_B) {
            int dist = p1.x - p2.x; if (dist<0) dist = -dist;
            if (dist < 32) damage(2, 80);
        }

        if (ko) {
            // end round, reset
            ko = 0;
            roundNum++;
            if (roundNum>3) { roundNum=1; p1Wins=0; p2Wins=0; }
            reset_round();
        }

        // TODO: draw HUD, sprites using OBJ, backgrounds
    }

    return 0;
}
